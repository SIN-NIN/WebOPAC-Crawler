﻿using System;
using System.Windows.Forms;
//using System.Resources;

namespace webOPACSearch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBoxResults.Text = Properties.Resources.Greeting;
            textBoxResults.Select(0, 0);
        }

        private void doSearch(string isn)
        {
            Cursor.Current = Cursors.WaitCursor;
            webOPACsearch w = new webOPACsearch(@"http://www.sierra.marmot.org/", isn, checkBoxShowUrlTree.Checked);
            textBoxResults.Text = w.ToString();
            textBoxResults.Select(0, 0);
            textBoxResults.Focus();
            Cursor.Current = Cursors.Default;
        }
        
        
        
        
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            doSearch(toolStripTextBox1.Text.Trim());
        }
        private void button2_Click(object sender, EventArgs e)
        {
            doSearch(toolStripTextBox1.Text = button2.Text);
        }
        private void toolStripTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                if (!toolStripTextBox1.AcceptsReturn)
                {
                    toolStripButton1.PerformClick();
                }
            }
        }

    }

    //---------------------------------------------------------------------------------------------------
    //
    //          borrowed stuff
    //
    //----------------------------------------------------------------------------------------------------
        


}
