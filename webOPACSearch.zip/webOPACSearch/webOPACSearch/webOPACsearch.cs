﻿using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;


namespace webOPACSearch
{
    public class webOPACsearch
    {
        private StringBuilder logos = new StringBuilder();
        private string httpServer;
        private List<string> keys = new List<string>();
        private List<bibRecord> bibs = new List<bibRecord>();
        private WebClient webClient = new WebClient();
        private pasteTranslate patty = new pasteTranslate();
        private Regex MarcExtractor = new Regex(@"<pre>(.*)</pre>", RegexOptions.Singleline);
        private int webchars;
        private bool showUrlTree;

        protected class bibUrl  // poop privatepublicprotected?
        {
            public string recnum;
            public string href;
            public bibUrl(string recnum, string href)
            {
                this.recnum = recnum;
                this.href = href;
            }
            public override string ToString()
            {
                return string.Format("[{0}] {1}", this.recnum, this.href);
            }
        }
        public class bibRecord
        {
            string recnum;
            string marcfields;
            string holdings;
            public bibRecord(string recnum, string marcfields, string holdings)
            {
                this.recnum = recnum;
                this.marcfields = marcfields;
                this.holdings = holdings;
            }
            public override string ToString()
            {
                return string.Format("#{0}\r\n{1}\r\n{2}", recnum, marcfields, holdings);
            }
            public int Length { get { return recnum.Length + marcfields.Length + holdings.Length; } }
        }
        public webOPACsearch(string httpServer, string key, bool showUrlTree)
        {
            webchars = 0;
            this.httpServer = httpServer;
            this.keys.Add(key);
            this.showUrlTree = showUrlTree;
            searchISN();
        }
        public bool searchISN()
        {
            foreach (string key in keys) webfind("i", key);
            return bibs.Count > 0;
        }

        private void webfind(string searchtype, string key)
        {
            Queue<bibUrl> urls = new Queue<bibUrl>();
            string searchMarmot = @"/search~S93?/";
            string typekey = searchtype + key;
            urls.Enqueue(new bibUrl("", searchMarmot + typekey));

            while (urls.Count > 0)
            {
                bibUrl url = urls.Dequeue();
                logos.AppendLine("Navigate: " + url.href);
                string page = webClient.DownloadString(httpServer + url.href);
                webchars += page.Length;
                if (isWebPacNoResult(page)) continue;
                else if (isWebPacBibMarc(page))
                {
                    logos.AppendLine("  is BibMarc Page");
                    Match m = MarcExtractor.Match(page);
                    if (m.Success)
                    {
                        string marc = WebUtility.HtmlDecode(m.Groups[1].ToString());
                        if (patty.Translate(marc)) marc = patty.Result;
                        bibRecord r = new bibRecord(url.recnum, marc, ""); // poop need the holdings...
                        if (!bibs.Contains(r)) { bibs.Add(r); logos.AppendLine("  ADD BIB"); } else logos.AppendLine("  REPEAT BIB RECORD");
                    }
                }
                else if (isWebPacBibItem(page))
                {
                    logos.AppendLine("  is BibItem Page");
                    url = getMarcDisplayUrl(page); // poop this needs a regex to return the bib number
                    urls.Enqueue(url);
                    logos.AppendLine("    enQ " + url.ToString());
                }
                else if (isWebPacIndexBrowse(page))
                {
                    logos.AppendLine("  is IndexBrowse Page");
                    List<bibUrl> early = getIndexBrowseLinks(page);
                    foreach (bibUrl u in early)
                    {
                        urls.Enqueue(u);
                        logos.AppendLine("  enQ " + u.ToString());
                    }
                }
                else if (isWebPacBibBrowse(page))
                {
                    logos.AppendLine("  is BibBrowse Page");
                    List<bibUrl> early = getBibBrowseLinks(page);
                    foreach (bibUrl u in early)
                    {
                        urls.Enqueue(u);
                        logos.AppendLine("  enQ " + u);
                    }
                }
            }
        }
        //==============================================================================
        //
        //          Not Found is always an option
        //
        //==============================================================================
            private bool hasBrief_Extended(string page)
            {
                return page.Contains("alt=\"Brief Display\"") | page.Contains("alt=\"Extended Display\"");
            }
            private bool hasNo_Matches_Found(string page)
            {
                return page.Contains("No matches found; nearby ");
            }
            private bool hasResult_Page(string page)
            {
                return page.Contains("Result Page");
            }
            private bool hasNext_Previous(string page)
            {
                return page.Contains("\"Previous\"") || page.Contains("\"Next\"");
            }
            private bool hasYour_Entry(string page)
            {
                return page.Contains("<b>Your entry");
            }

        private bool isWebPacNoResult(string page)
        {
            return hasBrief_Extended(page)
                & hasNo_Matches_Found(page)
                & hasResult_Page(page)
                & hasNext_Previous(page)
                & hasYour_Entry(page)
                ;
        }

        //==============================================================================
        //
        //          If it matched, it matched an entry in the ISN Index
        //
        //==============================================================================
            private bool hasLimit_Search(string page)
            {
                return page.Contains("Limit search to available items<br/>");
            }
            private bool hasSearchCount(string page)
            {
                return Regex.IsMatch(page, @"\(\d+-\d+ of \d+\)");
            }
            private bool hasCheckBoxes(string page)
            {
                return Regex.IsMatch(page, @"<input type=""checkbox""\s+name=""savegroup""");
            }
        
        private bool isWebPacIndexBrowse(string page)
        {
            return hasBrief_Extended(page)
                & hasLimit_Search(page)
                & hasSearchCount(page)
                & hasCheckBoxes(page)
                ;
        }
        
        private List<bibUrl> getIndexBrowseLinks(string page)
        {
            // poop do we get add to book bag buttons here as well?
            string pattern =
            @"<td class=""browseEntryData"">\s*<a name='anchor_\d+'></a> <a href=""(/search~S93\?/i[0-9xX]+/i[0-9xX]+/[^""]+)";
            var regChild = new Regex(pattern, RegexOptions.None);
            List<bibUrl> hrefs = new List<bibUrl>();

            MatchCollection mm = regChild.Matches(page);
            foreach (Match m in mm)
            {
                // poop we should not upgrade to marc...we need to hit the bibItem to find the butotn and the bib number
                string href = m.Groups[1].ToString().Replace("frameset&FF", "marc&FF");
                hrefs.Add(new bibUrl("", href));
            }
            return hrefs;
        }

        //==============================================================================
        //
        //          Or maybe we are a bit closer, the Bib Browse page
        //
        //==============================================================================
            private bool hasReturn_To_List(string page)
            {
                return page.Contains("alt=\"Return To Browse\"");
            }
            private bool hasSaveAll(string page)
            {
                return page.Contains("value=\"Save All On Page\" ></a>");
            }
            private bool hasLocate_In_Results(string page)
            {
                return page.Contains("value=\"Locate In Results\"");
            }
        private bool isWebPacBibBrowse(string page)
        {
            return hasLimit_Search(page)
                & hasSearchCount(page)
                & hasSaveAll(page)
                & !hasCheckBoxes(page);
        }
        private List<bibUrl> getBibBrowseLinks(string page)
        {
            string newpattern = @"return replace_or_redraw.*?save=(b\d+).*?Add to Book Bag.*?<span class=""briefcitTitle"">\s*<a href=""(/search~S93\?/i[0-9xX]+/i[0-9xX]+/[^""]+)";
            var regChild = new Regex(newpattern, RegexOptions.Singleline);
            List<bibUrl> us = new List<bibUrl>();

            MatchCollection mm = regChild.Matches(page);
            foreach (Match m in mm)
            {
                string recnum = m.Groups[1].ToString();
                string href = m.Groups[2].ToString().Replace("frameset&FF", "marc&FF");
                us.Add(new bibUrl(recnum, href));
            }
            return us;
        }
        //==============================================================================
        //
        //          So close we can taste it. Bib Item has a short description and holding info
        //
        //==============================================================================
            private bool hasMarcDisplay(string page)
            {
                return page.Contains("alt=\"MARC Display\"");
            }
        
        private bool isWebPacBibItem(string page)
        {
            return hasMarcDisplay(page);
        }
        private bibUrl getMarcDisplayUrl(string page)
        {
            // poop we need to actually get a bib number here...need a new regex.
            // we are looking for
            string recnumPattern = @"<a href=""/search~S93\?/[^>]*?save=(b\d+)";
            string hrefPattern = @"<a href=""(/search~S93\?/i[0-9xX]+/i[0-9xX]+/[^/]+/marc&FF=i[0-9xX]+[^""]+).+MARC Display";
            var regMarc = new Regex(hrefPattern, RegexOptions.None);
            string recnum = "";
            string href = "";

            Match m = Regex.Match(page, recnumPattern);
            if (m.Success)
            {
                href = m.Groups[1].ToString();
            }
            m = regMarc.Match(page);
            if (m.Success)
            {
                href = m.Groups[1].ToString(); // poop does groups[1] exist even if there was no success? an empty string back would be handy...
            }
            return new bibUrl(recnum, href); // poop this is kind of an unflagged error...

        }
        //==============================================================================
        //
        //          THis is it! the page that has the Bib record in Marc format
        //
        //==============================================================================
            private bool hasRegularDisplay(string page)
            {
                return page.Contains("alt=\"REGULAR RECORD DISPLAY\"");
            }
        
        private bool isWebPacBibMarc(string page)
        {
            return hasRegularDisplay(page);
        }

        //==============================================================================
        //
        //          This is how we return our bib records to the outside world
        //
        //==============================================================================
        public override string ToString()
        {
            int bibchars = 0;
            foreach (bibRecord bib in bibs) bibchars += bib.Length;
            double efficiency = 0;
            if (webchars != 0) efficiency = 100.0 * (double)bibchars / (double)webchars;

            logos.AppendLine().AppendLine(
                string.Format("extracted {0} characters of useful bib information from {1} chars of HTML code. Efficieny {2:0.00}%", bibchars, webchars, efficiency)).AppendLine();

            StringBuilder sb = new StringBuilder();
            if (showUrlTree) sb.Append(logos).AppendLine();

            foreach (bibRecord bib in bibs) sb.Append(bib).AppendLine();
            
            return sb.ToString();
        }
    }
}
