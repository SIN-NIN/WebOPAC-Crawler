﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace webOPACSearch
{
    class pasteTranslate
    {
        private abstract class translator
        {
            public string name;
            public string result;
            public abstract bool Translate(string input);
        }

        private translator[] translators;
        private string result;
        public string Result
        {
            get { return result; }
        }
        public bool Translate(string input)
        {
            translators = new translator[] { new transMarcEdit(), new transMillennium(), new transCatalog(), new transVuFind() };
            result = "";
            foreach (translator t in translators)
            {
                if (t.Translate(input))
                {
                    result = "#Pasted from " + t.name + Environment.NewLine + t.result; return true;
                }
            }
            return false;
        }

        private class transMarcEdit : translator // (string input)
        {
            public override bool Translate(string input)
            {
                name = "MarcEdit";
                result = "";
                input = input.Replace("\r\n", "\n");
                var regMarcEdit = new Regex(@"^=(LDR|[0-9]{3})  (.*)");
                var lines = input.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string line in lines)
                    if (!regMarcEdit.IsMatch(line))
                        return false;
                result = input;
                return true;
            }
        }

        private class transMillennium : translator
        {
            public override bool Translate(string input)
            {
                name = "Millennium";
                result = "";
                input = input.Replace("\r\n", "\n");
                var regMillenniumJunk = new Regex(
                    @"^\s*(LANG.*CAT DATE.*SPEC'L USE|SKIP.*BIB LVL.*COUNTRY|LOCATION.*MAT TYPE|LOCATIONS|Z39.50).*"
                );
                var regMillenniumLeader = new Regex(@"^\s*MARC Leader\s*(.*)");
                var regMillenniumField = new Regex(@"^[a-z]\t([0-9]{3})\t([0-9 ])\t([0-9 ])\t(.*)");
                var sb = new StringBuilder();
                var lines = input.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string line in lines)
                {
                    if (regMillenniumJunk.IsMatch(line)) continue;
                    if (regMillenniumLeader.IsMatch(line))
                    {
                        sb.AppendLine(regMillenniumLeader.Replace(line, "=LDR  $1"));
                        continue;
                    }
                    Match m = regMillenniumField.Match(line);
                    if (m.Success)
                    {
                        string tag = m.Groups[1].ToString();
                        string indicator1 = m.Groups[2].ToString().Replace(' ', '\\');
                        string indicator2 = m.Groups[3].ToString().Replace(' ', '\\');
                        string leadingSubfield = "$a";
                        string body = m.Groups[4].ToString();
                        var x = Int16.Parse(tag);
                        if (x < 10) indicator1 = indicator2 = leadingSubfield = "";
                        else
                        {
                            if (body.StartsWith("|a")) body = body.Substring(2);
                            body = body.Replace('|', '$');
                        }
                        sb.AppendFormat("={0}  {1}{2}{3}{4}", tag, indicator1, indicator2, leadingSubfield, body).AppendLine();
                        continue;
                    }
                    return false;
                }
                result = sb.ToString();
                return true;
            }
        }

        private class transCatalog : translator // adds leading subfields
        {
            public override bool Translate(string input)
            {
                name = "Catalog";
                input = input.Replace("\r\n", "\n");
                input = Regex.Replace(input, @"\n       (?=\S)", "", RegexOptions.Multiline);
                var regCatLeader = new Regex(@"^LEADER (\S.*)");
                var regCatField = new Regex(@"^([0-9]{3}) ([0-9 ]{2}) (.*)");

                var sb = new StringBuilder();
                var lines = input.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string line in lines)
                {
                    if (regCatLeader.IsMatch(line))
                    {
                        sb.AppendLine(regCatLeader.Replace(line, "=LDR  $1"));
                        continue;
                    }
                    Match m = regCatField.Match(line);
                    if (m.Success)
                    {
                        string tag = m.Groups[1].ToString();
                        var x = Int16.Parse(tag);
                        string indicators = m.Groups[2].ToString().Replace(' ', '\\');
                        string leadingSubfield = "$a";
                        string body = m.Groups[3].ToString();
                        if (x < 10) indicators = leadingSubfield = "";
                        else
                        {
                            if (body.StartsWith("|a")) body = body.Substring(2);
                            body = body.Replace('|', '$');
                        }
                        sb.AppendFormat("={0}  {1}{2}{3}", tag, indicators, leadingSubfield, body).AppendLine();
                        continue;
                    }
                    return false;
                }
                result = sb.ToString();
                return true;
            }
        }

        private class transVuFind : translator // already has leading subfields
        {
            public override bool Translate(string input)
            {
                name = "VuFind";
                input = input.Replace("\r\n", "\n");
                var regVuFindLeader = new Regex(@"^LEADER (\S.*)");
                // single space for control fields
                // 3 spaces data fields no indicators
                // space indicator space space if just indicator1
                // space space indicator space if just indicator2
                // space indicator space indicator space if two indicators
                var regVuFindControlField = new Regex(@"^(00[0-9]) (\S.*)");
                var regVuFindDataField = new Regex(@"^([0-9]{3})(   | [0-9]  |  [0-9] | [0-9] [0-9] )(\S.*)");
                var regVuFindInteriorSubfields = new Regex(@" \|(\w) ");

                var sb = new StringBuilder();
                var lines = input.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string line in lines)
                {
                    if (regVuFindLeader.IsMatch(line))
                    {
                        sb.AppendLine(regVuFindLeader.Replace(line, "=LDR  $1"));
                        continue;
                    }
                    if (regVuFindControlField.IsMatch(line))
                    {
                        sb.AppendLine(regVuFindControlField.Replace(line, "=$1  $2"));
                        continue;
                    }

                    Match m = regVuFindDataField.Match(line);
                    if (m.Success)
                    {
                        string tag = m.Groups[1].ToString();
                        var x = Int16.Parse(tag);
                        string indicators = m.Groups[2].ToString();
                        string leadingSubfield = "$a";
                        string body = m.Groups[3].ToString();
                        int len = indicators.Length;
                        if (len == 4) indicators = indicators.Substring(1, 2).Replace(' ', '\\');
                        else if (len == 5) indicators = new string(new char[] { indicators[1], indicators[3] });
                        else indicators = @"\\";
                        if (x < 10) indicators = leadingSubfield = "";
                        else
                        {
                            if (body.StartsWith("|a ")) body = body.Substring(3);
                            body = regVuFindInteriorSubfields.Replace(body, "$$$1");
                        }

                        sb.AppendFormat("={0}  {1}{2}{3}", tag, indicators, leadingSubfield, body).AppendLine();
                        continue;
                    }
                    return false;
                }
                result = sb.ToString();
                return true;
            }
        }
    }
}
